/*----------------------------------------------------------------------------*/
/* Les pilotes de périphériques.                                              */
/*----------------------------------------------------------------------------*/
#define MANUX_VIRTIO

/*
 * Du réseau
 */
//#define MANUX_VIRTIO_NET

/*
 * Une console
 */
#define MANUX_VIRTIO_CONSOLE

/*
 * Le numéro majeur des consoles virtio
 */
#define MANUX_VIRTIO_CONSOLE_MAJEUR 1

